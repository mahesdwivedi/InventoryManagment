-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `inventory` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `inventory`;

DROP TABLE IF EXISTS `login_detail`;
CREATE TABLE `login_detail` (
  `username` varchar(40) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `product_detail_id` int(8) NOT NULL,
  `quantity` int(8) NOT NULL,
  `barcode` int(50) NOT NULL,
  `date_of_creation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_of_modification` datetime DEFAULT NULL,
  `user_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `product_detail_id` (`product_detail_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `product_ibfk_2` FOREIGN KEY (`product_detail_id`) REFERENCES `product_detail` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user_detail` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product` (`id`, `name`, `product_detail_id`, `quantity`, `barcode`, `date_of_creation`, `date_of_modification`, `user_id`) VALUES
(1,	'sprite',	1,	2,	89,	'2019-06-17 14:52:21',	NULL,	1);

DROP TABLE IF EXISTS `product_detail`;
CREATE TABLE `product_detail` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(40) DEFAULT NULL,
  `sku` varchar(20) NOT NULL,
  `image` varchar(40) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `minimum_qty` int(11) DEFAULT NULL,
  `date_of_creation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product_detail` (`id`, `name`, `description`, `sku`, `image`, `color_id`, `minimum_qty`, `date_of_creation`) VALUES
(1,	'sprite',	'fcvkldsfvjn',	'567899',	NULL,	NULL,	10,	'0000-00-00 00:00:00'),
(2,	'lenovo',	'gvj',	'13254',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(3,	'kkk',	'kkk',	'7890',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(4,	'kkk',	'kkk',	'7890',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(5,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(6,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(7,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(8,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(9,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(10,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(11,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(12,	'paper',	'name',	'78900',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00'),
(13,	'jlklkloip',	'hj',	'mnmn',	NULL,	NULL,	NULL,	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `date_of_creation` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `role` (`id`, `name`, `date_of_creation`) VALUES
(1,	'admin',	'2019-06-18 16:46:43');

DROP TABLE IF EXISTS `user_detail`;
CREATE TABLE `user_detail` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(11) NOT NULL,
  `firstname` varchar(40) DEFAULT NULL,
  `lastname` varchar(40) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `responsibility` varchar(40) DEFAULT NULL,
  `date_of_creation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_of_modification` datetime DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `role` (`role`),
  CONSTRAINT `user_detail_ibfk_1` FOREIGN KEY (`role`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user_detail` (`id`, `emp_id`, `firstname`, `lastname`, `email`, `username`, `password`, `responsibility`, `date_of_creation`, `date_of_modification`, `role`) VALUES
(1,	'0619-89898',	'Mahes',	'Dwivedi',	'xyz@gmail.com',	'admin',	'admin',	'none',	'2019-06-17 14:53:34',	'2019-06-26 00:00:14',	1),
(2,	'0619-89899',	'Mahes1',	'Dwivedi1',	'xyz1@gmail.com',	'admin1',	'xyz',	'none',	'2019-06-18 15:34:49',	NULL,	1);

-- 2019-06-18 11:36:26
